jQuery(function($) {
	
	var path=window.location;	

	$('.popup-background').click(function(event){
		$('.popup-background').removeClass('popup-widget-overlay');
		$('.popup-popup-content').css({
			'display': 'none'
		});
		$('.popup-more-content').css({
			'display': 'none'
		});
		$('.popup__content').html('');
	});
	
	$('.required').blur(function () {
		var id = $(this).attr('id');
		fieldcheck(id,['required']);
	});		
	$('.email').blur(function () {
		var id = $(this).attr('id');
		fieldcheck(id,['required','email']);
	});
	
});

function closePopup()
{
	$('.popup-background').removeClass('popup-widget-overlay');
	$('.popup-popup-content').css({
		'display': 'none'
	});	
	$('.popup-more-content').css({
		'display': 'none'
	});
	$('.popup__content').html('');
	$('.more__content').html('');
}
function closemorePopup()
{
	$('.popup-more-content').css({
		'display': 'none'
	});
	$(".popup-popup-content").animate({left:"33%"}, 800 );
	$('.more__content').html('');
}

/* AGENT */

/* Add */

function campaignaddpopup()
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/customer_campaign/add";	
	$.post(url,{},function(data) {	
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});
}

/* cc_la_sa_campaign_add*/
function cc_campaignaddpopup()
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/county_coordinator_campaign/add";	
	$.post(url,{},function(data) {	
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});
}

function la_campaignaddpopup()
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/lead_agent_campaign/add";	
	$.post(url,{},function(data) {	
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});
}

function sa_campaignaddpopup()
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/sub_agent_campaign/add";
	$.post(url,{},function(data) {
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});
}

/*               */

function agentaddpopup()
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/agent/add";
	$.post(url,{},function(data) {
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});
}

//------------------ILRL ADD-------------------//

function ilriaddpopup()
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/ilri/add";	
	$.post(url,{},function(data) {	
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});
}

function ilrieditpopup(id)
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/ilri/edit";	

	$.post(url,{id:id},function(data) {
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});	
}

//---------------Function Added by Athul---------------//

function get_weatherdivisionc(selc)
{
	//alert("hi");
	var county_id=selc.value;
	var field_id=selc.id;
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/report/get_weatherdivisionc";	
	$.post(url,{county_id:county_id},function(data) { //alert(data);
		if(data!='')
		{
			if(field_id=='county')
			{
				$('#city').html(data);
			}
			else if (field_id=='ecounty') 
			{
				$('#ecity').html(data);
			};
		}
		else
		{
			$('#city').html("<option value=''>Select weather division</option>");
		}
	});
}
function get_placec(getc1)
{
	var city_id=getc1.value;
	var field_id=getc1.id;
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/report/get_placec";	
	//alert(city_id);
	//alert(url);
	$.post(url,{city_id:city_id},function(data) { 
		//alert(data);
		if(data!='')
		{
			if(field_id=='city')
			{
				$('#place').val(data);
			}
			else if(field_id=='ecity')
			{
				$('#eplace').val(data);
			}
		}
		else
		{
			$('#place1').html('<input type="text" value="" class="input" name="eplace" id="eplace" placeholder="Place">');
		}
	});
}

function get_placec1(getc1)
{
	var city_id=getc1.value;
	var field_id=getc1.id;
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/sub_agent/get_placec";	
	//alert(city_id);
	//alert(url);
	$.post(url,{city_id:city_id},function(data) { 
		//alert(data);
		if(data!='')
		{
			if(field_id=='city')
			{
				$('#place').val(data);
			}
			else if(field_id=='ecity')
			{
				$('#eplace').val(data);
			}
		}
		else
		{
			$('#place1').html('<input type="text" value="" class="input" name="eplace" id="eplace" placeholder="Place">');
		}
	});
}

///////////////////////////TRIGGER///////////////////////////
function get_trigger(trigger)
{
	var division_id=trigger.value;
	var field_id=trigger.id;
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/payout/get_trigger";	
	//alert(division_id);
	$.post(url,{division_id:division_id},function(data) { 
		//alert(data);
		if(data!='')
		{
			if(field_id=='city')
			{
				$('#trigger').val(data);
			}
			else if(field_id=='ecity')
			{
				$('#etrigger').val(data);
			}
			
		}
		else
		{
			$('#trigger').html('<input type="text" value="" class="input" name="trigger" id="trigger" placeholder="Trigger (in %)">'); //<input type="text" value="" class="input" name="eplace" id="eplace" placeholder="Place">
		}
	});
}

function get_deductable(deductable)
{
	var deductable=deductable.value;

	// var split=trigger.split("_");
	// var trigger_value=split[0];
	// var weather_division_id=split[1];
	// var deductable=split[2];
	// var field_id=deductable.id;


	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/payout/get_deductable";	
	$.post(url,{deductable:deductable},function(data) { 
		if(data!='')
		{
			$('#deductable').val(deductable);
		}
		else
		{
			$('#deductable').html('<input type="text" value="" class="input" name="deductable" id="deductable" placeholder="deductable (in %)">'); //<input type="text" value="" class="input" name="eplace" id="eplace" placeholder="Place">
		}
	});
}

function get_lead_agentcountyId(countyId)
{
	var Id=countyId.value;
	var split=Id.split("_");
	var id=split[0];
	var countyId=split[1];
	var username=split[2];

	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/sub_agent/get_county_id";

	$.post(url,{countyId:countyId},function(data) { //alert(data);
		if(data!='')
		{
			$('#super_agentid').val(id);
			$('#super_agentcod').val(username);
			$('#county').val(countyId);
			$('#city').html(data);
		}
		else
		{
			$('#city').html("<option value=''>Select weather division</option>");
		}
	});
}

function get_price(data)
{
	var product_id = document.getElementById('product').value;
	var rate = (data.value)/100;
	var field_id = data.id;
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/manageprice/get_price";	

	$.post(url,{product_id:product_id,rate:rate},function(data) { 

		if(data!='')
		{
			if(field_id=='rate')
			{
				$('#price').val(data);
			}
			else if(field_id=='erate')
			{
				$('#eprice').val(data);
			}
		}
		else
		{
			$('#price').html('<input type="text" value="" class="input" name="price" id="price" placeholder="Price">');
		}
	});
}


//--------------------------------------------------------------------------------//

function agenteditpopup(id)
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/agent/edit";	

	$.post(url,{id:id},function(data) {
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});	
}


/* Underwriter */

/* Add */
function underwriteraddpopup()
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/underwriter/add";	
	$.post(url,{},function(data) {	
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});
}

function underwritereditpopup(id)
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/underwriter/edit";	

	$.post(url,{id:id},function(data) {
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});	
}

/* County Co-ordinator */

/* Add */
function c_coordinatoraddpopup()
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/county_coordinator/add";	
	$.post(url,{},function(data) {	
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});
}

function c_coordinatoreditpopup(id)
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/county_coordinator/edit";	

	$.post(url,{id:id},function(data) {
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});	
}

/* Sub Agent */

/* Add */
function subagentaddpopup()
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/sub_agent/add";	
	$.post(url,{},function(data) {	
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});
}

function subagenteditpopup(id)
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/sub_agent/edit";	

	$.post(url,{id:id},function(data) {
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});	
}
function validateagent_id(id)
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/sub_agent/validateuser";	
	$.post(url,{id:id},function(data) {	//alert(data);
		if(data=='invalid agent id')
		{
			document.getElementById('error_super_agentid').innerHTML = data;
			fail_border('error_super_agentid');
		}
		else
		{
			document.getElementById('error_super_agentid').innerHTML = '';
			success_border('error_super_agentid');
			document.getElementById('super_agentid').value = data;
		}	
	});
		
}	
/* Cover */

function covereditpopup(id)
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/cover/edit";	

	$.post(url,{id:id},function(data) {
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});
}

function coverhistorypopup(policyid)
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/cover/cover_history";	

	$.post(url,{policyid:policyid},function(data) {
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});
}

function customerdetails(id)
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/cover/customerdetails";	

	$.post(url,{id:id},function(data) {
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.more__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$(".popup-popup-content").animate({left:"10%"}, 800 );
			var delay=800;
			setTimeout(function(){
				$('.popup-more-content').css({
					'display': 'block',
					'height': 'auto',
					'left': '10%',
					'margin-left': '560px',
					'position': 'absolute',
					'top': '17px',
					'width': '535px',
					'z-index': '999'
				});
			},delay);
		}
		else
		{
			var form='Invalid Request';
		}
	});
}

function agentdetails(id)
{	
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/cover/agentdetails";	

	$.post(url,{id:id},function(data) {	
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.more__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$(".popup-popup-content").animate({left:"10%"}, 800 );
			var delay=800;
			setTimeout(function(){
				$('.popup-more-content').css({
					'display': 'block',
					'height': 'auto',
					'left': '10%',
					'margin-left': '560px',
					'position': 'absolute',
					'top': '17px',
					'width': '535px',
					'z-index': '999'
				});
			},delay);
		}
		else
		{
			var form='Invalid Request';
		}
	});
}

/* Window Management */

/* Add */
function windowaddpopup()
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/manage_window/add";	
	$.post(url,{},function(data) {	
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});
}

function windoweditpopup(id)
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/manage_window/edit";	

	$.post(url,{id:id},function(data) {
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});	
}

/* Payment */

/* Add */
function paymentaddpopup()
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/payment/add";	
	$.post(url,{},function(data) {	
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});
}
//////////////////// PAYouT//////////////////////////
function payoutaddpopup()
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/payout/add";	
	$.post(url,{},function(data) {	
		if(data!='')
		{
			//alert(data);
	
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});
}

function paymenteditpopup(id)
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/payment/edit";	

	$.post(url,{id:id},function(data) {
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});	
}

function payouteditpopup(id)
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/payout/edit";	

	$.post(url,{id:id},function(data) {
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});	
}

////////////////////////////new function////////////////////////////////////////
function get_lead_agent(agentId)
{
	var Id=agentId.value;

	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/report/get_agent";

	$.post(url,{Id:Id},function(data) { //alert(data);
		if(data!='')
		{
			$('#lead_agentid').html(data);
			
		}
		else
		{
			$('#lead_agentid').html("<option value=''>Select Agent</option>");
		}
	});
}

function get_sub_agent(leadagentId)
{
	var lead_id=leadagentId.value;

	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/report/get_subagent";
	//alert(lead_id);
	$.post(url,{lead_id:lead_id},function(data) { //alert(data);
		if(data!='')
		{
			$('#sub_agentid').html(data);
			
		}
		else
		{
			$('#sub_agentid').html("<option value=''>Select Sub Agent</option>");
		}
	});
}

/////////////////////////// production report /////////////////////////////////

// function county_production_report()
// {
// 	var pathstring = String(window.location);
// 	var patharray  = pathstring.split("/");		
// 	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
// 	var url = path+"/index.php/report/county_report_add";	
// 	$.post(url,{},function(data) {	
// 		if(data!='')
// 		{
// 			$("html, body").animate({ scrollTop: 0 }, 500);					
// 			$('.popup__content').html(data);
// 			$('.popup-background').addClass('popup-widget-overlay');
// 			$('.popup-popup-content').css({
// 				'display': 'block',
// 				'height': 'auto',
// 				'left': '33%',
// 				'position': 'absolute',
// 				'top': '17px',
// 				'width': '535px',
// 				'z-index': '999'
// 			});
// 		}
// 		else
// 		{
// 			var form='Invalid Request';
// 		}
// 	});
// }
function weather_division_production_report()
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/report/weather_division_report_add";	
	$.post(url,{},function(data) {	
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});
}

function lead_agent_production_report()
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/report/lead_agent_report_add";	
	$.post(url,{},function(data) {	
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});
}

function sub_agent_production_report()
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/report/sub_agent_report_add";	
	$.post(url,{},function(data) {	
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});
}

function product_production_report()
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/report/product_report_add";	
	$.post(url,{},function(data) {	
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});
}

function monthly_production_report()
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/report/monthly_report_add";	
	$.post(url,{},function(data) {	
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});
}

function free_date_production_report()
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/report/freedate_report_add";	
	$.post(url,{},function(data) {	
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});
}

function client_production_report()
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/report/client_report_add";	
	$.post(url,{},function(data) {	
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});
}

function gender_production_report()
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/report/gender_report_add";	
	$.post(url,{},function(data) {	
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});
}

function agent_gender_production_report()
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/report/agent_gender_report_add";	
	$.post(url,{},function(data) {	
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});
}

function compare_window_report()
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/report/compare_window_report_add";	
	$.post(url,{},function(data) {	
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});
}

/*--   04/11/15  --*/
function new_renewal_report()
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/report/new_renewal_report_add";	
	$.post(url,{},function(data) {	
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});
}

/*--   24/11/15  --*/
function agent_info_report()
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/report/agent_info_report_add";	
	$.post(url,{},function(data) {	
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});
}

///////////////////////////////////ended//////////////////////////////////////////////////

////////////////////////////////// commission report /////////////////////////////////////

function county_commission_report()
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/report/county_commission_report_add";	
	$.post(url,{},function(data) {	
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});
}

function lead_agent_commission_report()
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/report/lead_agent_commission_report_add";	
	$.post(url,{},function(data) {	
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});
}

function sub_agent_commission_report()
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/report/sub_agent_commission_report_add";	
	$.post(url,{},function(data) {	
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});
}


/////////////////////////////////// ended /////////////////////////////////////////

/*-----------------------Manage County-----------------------*/

function countyaddpopup()
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/managecounty/addcounty";	
	$.post(url,{},function(data) {	
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});
}

function countyeditpopup(id)
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/managecounty/editcounty";	
	$.post(url,{id:id},function(data) {	
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});
}


/*-----------------------Manage Weather Division-----------------------*/

function weatherdivisionaddpopup()
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/manageweatherdivision/addweatherdivision";	
	$.post(url,{},function(data) {	
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});
}

function weatherdivisioneditpopup(id)
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/manageweatherdivision/editweatherdivision";	
	$.post(url,{id:id},function(data) {	
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});
}

/*---------------------manage price--------------------*/

function priceaddpopup()
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/manageprice/addmanageprice";	
	$.post(url,{},function(data) {	
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});
}

function priceeditpopup(id)
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/manageprice/editmanageprice";	
	$.post(url,{id:id},function(data) {	
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});
}

/*----------------manage product-----------------*/

function producteditpopup(id)
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/manageproduct/editmanageproduct";	
	$.post(url,{id:id},function(data) {	
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});
}

function checkrequired(id){			
	// var fname = document.getElementById("name").value;
	var fname = $('#'+id).val();				

	if (fname == "") {
		$('#'+id).addClass('input__error');
		return true;
	} else {
		$('#'+id).removeClass('input__error');
		return false;
	}		
};

function checkemail(id){		
	var nameRegex = /^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/i;
	// var fname = document.getElementById("name").value;
	var fname = $('#'+id).val();				

	if (fname == "") {
		$('#'+id).addClass('input__error');
		return true;
	} else if (!(nameRegex.test(fname))) {
		$('#'+id).addClass('input__error');	
		return true;
	} else {
		$('#'+id).removeClass('input__error');
		return false;
	}		
};

function agent_registration_validation()
{	
	 if(formsubmit('','agent_registration', [['required','f_name','l_name','contact_no','male','county','city','kra_pin','id'],['email','email'],['telno','contact_no']],''))
	 {
	 	
	 	return true;
	 }

	 else
	 {
	 	return false;
	 }
}
function edit_agent_registration_validation()
{	
	 if(formsubmit('','edit_agent_registration', [['required','ef_name','el_name','econtact_no','emale','ecounty','ecity','ekra_pin','eid'],['email','eemail'],['telno','econtact_no']],''))
	 {	 	
	 	return true;
	 }
	 else
	 {
	 	return false;
	 }	 
}

function subagent_registration_validation()
{	
	 if(formsubmit('','subagent_registration', [['required','f_name','l_name','contact_no','male','city','business_type','business_name','agent_type','business_pin','location','sub_location','name_chief','phone_chief','location_chief','nok','plb','lb'],['email','email'],['telno','contact_no'],['telno','phone_chief']],''))
	 {
	 	return true;
	 }

	 else
	 {
	 	return false;
	 }
}

function edit_subagent_registration_validation()
{	
	 if(formsubmit('','edit_subagent_registration', [['required','ef_name','el_name','econtact_no','emale','ecity','ebusiness_type','ebusiness_name','eagent_type','ebusiness_pin','elocation','esub_location','ename_chief','ephone_chief','elocation_chief','enok','eplb','elb'],['email','eemail'],['telno','econtact_no'],['telno','ephone_chief']],''))
	 {
	 	
	 	return true;
	 }

	 else
	 {
	 	return false;
	 }
}

function county_registration_validation()
{	
	 if(formsubmit('','county_registration', [['required','f_name','l_name','contact_no','county','city'],['email','email'],['telno','contact_no']],''))
	 {
	 	
	 	return true;
	 }

	 else
	 {
	 	return false;
	 }
}

function edit_county_registration_validation()
{	
	 if(formsubmit('','edit_county_registration', [['required','ef_name','el_name','econtact_no','ecounty','ecity'],['email','eemail'],['telno','econtact_no']],''))
	 {
	 	
	 	return true;
	 }

	 else
	 {
	 	return false;
	 }
}

function underwriter_registration_validation()
{	
	 if(formsubmit('','underwriter_registration', [['required','f_name','l_name','contact_no'],['email','email'],['telno','contact_no']],''))
	 {
	 	
	 	return true;
	 }

	 else
	 {
	 	return false;
	 }
}

function edit_underwriter_registration_validation()
{	
	 if(formsubmit('','edit_underwriter_registration', [['required','ef_name','el_name','econtact_no'],['email','eemail'],['telno','econtact_no']],''))
	 {
	 	
	 	return true;
	 }

	 else
	 {
	 	return false;
	 }
}

function trigger_registration_validation()
{	
	 if(formsubmit('','trigger_registration', [['required','window','county','city','trigger']],''))
	 {
	 	
	 	return true;
	 }

	 else
	 {
	 	return false;
	 }
}
function edit_trigger_registration_validation()
{	
	 if(formsubmit('','edit_trigger_registration', [['required','ewindow','ecounty','ecity','etrigger']],''))
	 {
	 	
	 	return true;
	 }

	 else
	 {
	 	return false;
	 }
}

function payout_registration_validation()
{	
	 if(formsubmit('','payout_registration', [['required','window','county','city','trigger']],''))
	 {
	 	
	 	return true;
	 }

	 else
	 {
	 	return false;
	 }
}
function edit_payout_registration_validation()
{	
	 if(formsubmit('','edit_payout_registration', [['required','ewindow','ecounty','ecity','etrigger']],''))
	 {
	 	
	 	return true;
	 }

	 else
	 {
	 	return false;
	 }
}


function window_registration_validation()
{	
	 if(formsubmit('','window_registration', [['required','window_name','start_date','end_date']],''))
	 {
	 	
	 	return true;
	 }

	 else
	 {
	 	return false;
	 }
}
function edit_window_registration_validation()
{	
	 if(formsubmit('','edit_window_registration', [['required','ewindow_name','estart_date','eend_date']],''))
	 {
	 	
	 	return true;
	 }

	 else
	 {
	 	return false;
	 }
}

//--------------------ILRI-------------------------//

function ilri_registration_validation()
{	
	 if(formsubmit('','ilri_registration', [['required','f_name','l_name','email','contact_no','county','city','company_name'],['email','email'],['telno','contact_no']],''))
	 {
	 	
	 	return true;
	 }

	 else
	 {
	 	return false;
	 }
}
function edit_ilri_registration_validation()
{	
	 if(formsubmit('','edit_ilri_registration', [['required','ef_name','el_name','eemail','econtact_no','ecounty','ecity','ecompany_name'],['email','eemail'],['telno','econtact_no']],''))
	 {	 	
	 	return true;
	 }
	 else
	 {
	 	return false;
	 }	 
}


// function county_production_registration_validation()
// {	
// 	 if(formsubmit('','production_validation_per_county', [['required','window','county']],''))
// 	 {
	 	
// 	 	return true;
// 	 }

// 	 else
// 	 {
// 	 	return false;
// 	 }
// }

function weatherdivision_production_registration_validation()
{	
	 if(formsubmit('','production_validation_per_weatherdivision', [['required','window']],''))
	 {
	 	
	 	return true;
	 }

	 else
	 {
	 	return false;
	 }
}

function leadagent_production_registration_validation()
{	
	 if(formsubmit('','production_validation_per_leadagent', [['required','window','county','lead_agentid']],''))
	 {
	 	
	 	return true;
	 }

	 else
	 {
	 	return false;
	 }
}

function subagent_production_registration_validation()
{	
	 if(formsubmit('','production_validation_per_subagent', [['required','window','county','lead_agentid','sub_agentid']],''))
	 {
	 	
	 	return true;
	 }

	 else
	 {
	 	return false;
	 }
}

function subagent_production_registration_validation_1()
{	
	 if(formsubmit('','production_validation_per_subagent', [['required','window','sub_agentid']],''))
	 {
	 	
	 	return true;
	 }

	 else
	 {
	 	return false;
	 }
}

function product_production_registration_validation()
{	
	 if(formsubmit('','production_validation_per_product', [['required','window','product']],''))
	 {
	 	
	 	return true;
	 }

	 else
	 {
	 	return false;
	 }
}

function monthly_production_registration_validation()
{	
	 if(formsubmit('','production_validation_per_monthly', [['required']],''))
	 {
	 	
	 	return true;
	 }

	 else
	 {
	 	return false;
	 }
}

function freedate_production_registration_validation()
{	
	 if(formsubmit('','production_validation_per_freedate', [['required','window','from_date','to_date']],''))
	 {
	 	
	 	return true;
	 }

	 else
	 {
	 	return false;
	 }
}

function client_production_registration_validation()
{	
	 if(formsubmit('','client_validation_per_product', [['required','window','client']],''))
	 {
	 	
	 	return true;
	 }

	 else
	 {
	 	return false;
	 }
}

function gender_production_registration_validation()
{	
	 if(formsubmit('','production_validation_per_gender', [['required','gender']],''))
	 {
	 	
	 	return true;
	 }

	 else
	 {
	 	return false;
	 }
}

function partner_registration_validation()
{	
	 if(formsubmit('','partner_registration', [['required','company_name','abbreviation']],''))
	 {
	 	
	 	return true;
	 }

	 else
	 {
	 	return false;
	 }
}

function agent_gender_production_registration_validation()
{	
	 if(formsubmit('','production_validation_per_agentgender', [['required','window','gender']],''))
	 {
	 	
	 	return true;
	 }

	 else
	 {
	 	return false;
	 }
}

function compare_window_registration_validation()
{	
	 if(formsubmit('','compare_window_validation', [['required','window','window1']],''))
	 {
	 	
	 	return true;
	 }

	 else
	 {
	 	return false;
	 }
}

/*--  04/11/15  --*/

function get_new_renewal_validation()
{	
	 if(formsubmit('','new_renewal_validation', [['required','new_renewal']],''))
	 {
	 	return true;
	 }

	 else
	 {
	 	return false;
	 }
}

/*--  24/11/15  --*/
function create_agent_info_report_validation()
{	
	 if(formsubmit('','production_validation_create_agent_info_report_validation', [['required','county']],''))
	 {
	 	return true;
	 }

	 else
	 {
	 	return false;
	 }
}

function county_commission_registration_validation()
{	
	 if(formsubmit('','commission_validation_per_county', [['required','county']],''))
	 {
	 	return true;
	 }

	 else
	 {
	 	return false;
	 }
}
function leadagent_commission_registration_validation()
{	
	 if(formsubmit('','commission_validation_per_leadagent', [['required','window','county','lead_agentid']],''))
	 {
	 	
	 	return true;
	 }

	 else
	 {
	 	return false;
	 }
}
function leadagent_commission_registration_validation_1()
{	
	 if(formsubmit('','commission_validation_per_leadagent', [['required','window']],''))
	 {
	 	
	 	return true;
	 }

	 else
	 {
	 	return false;
	 }
}
function subagent_commission_registration_validation()
{	
	 if(formsubmit('','commission_validation_per_subagent', [['required','window','county','lead_agentid','sub_agentid']],''))
	 {
	 	
	 	return true;
	 }

	 else
	 {
	 	return false;
	 }
}

function subagent_commission_registration_validation_1()
{	
	 if(formsubmit('','commission_validation_per_subagent', [['required','window','sub_agentid']],''))
	 {
	 	
	 	return true;
	 }

	 else
	 {
	 	return false;
	 }
}
function subagent_commission_registration_validation_2()
{	
	 if(formsubmit('','commission_validation_per_subagent', [['required','window']],''))
	 {
	 	
	 	return true;
	 }

	 else
	 {
	 	return false;
	 }
}

/*-----------------manage county------------------*/

function manage_county_validation()
{
	if(formsubmit('','manage_county_registration', [['required','county']],''))
	 {
	 	
	 	return true;
	 }

	 else
	 {
	 	return false;
	 }
}

function edit_manage_county_validation()
{
	if(formsubmit('','edit_manage_county_registration', [['required','ecounty']],''))
	 {
	 	
	 	return true;
	 }

	 else
	 {
	 	return false;
	 }
}

/*-----------------manage weather division------------------*/

function manage_weatherdivision_validation()
{
	if(formsubmit('','manage_weatherdivision_registration', [['required','county','city','code']],''))
	 {
	 	
	 	return true;
	 }

	 else
	 {
	 	return false;
	 }
}

function edit_manage_weatherdivision_validation()
{
	if(formsubmit('','edit_manage_weatherdivision_registration', [['required','ecounty','ecity','ecode']],''))
	 {
	 	
	 	return true;
	 }

	 else
	 {
	 	return false;
	 }
}

/*------------------manage price-------------------*/

function manage_price_validation()
{
	if(formsubmit('','manage_price_registration', [['required','product','county','city','rate','price']],''))
	 {
	 	
	 	return true;
	 }

	 else
	 {
	 	return false;
	 }
}

function edit_manage_price_validation()
{
	if(formsubmit('','edit_manage_price_registration', [['required','eproduct','ecounty','ecity','erate','eprice']],''))
	 {
	 	
	 	return true;
	 }

	 else
	 {
	 	return false;
	 }
}

/* 10/11/15 */

function campaign_validation()
{
	if(formsubmit('','campaign_registration', [['required','county','title','msg']],''))
	 {
	 	
	 	return true;
	 }

	 else
	 {
	 	return false;
	 }
}

/*  */

function fieldcheck(element_id,ruleArray)
{
var total = 0;
var total = ruleArray.length - 1;
	for(i=0;i<ruleArray.length;i++)
	{
		if(ruleArray[i]=='required')
		{	
			if(document.getElementById(element_id).value.trim() != '' && i==total)
			{
				success_border(element_id);
				document.getElementById('error_'+element_id).innerHTML = '';
			}
			else if(document.getElementById(element_id).value.trim() != '' && i!=total)
			{
				continue;
			}
			else
			{
				document.getElementById('error_'+element_id).innerHTML = 'Required';
				fail_border(element_id);
				break;
			}
		}
		if(ruleArray[i]=='email')
		{
			if(document.getElementById(element_id).value.trim() != '')
			{
				if(/^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/i.test(document.getElementById(element_id).value) && i==total)
				{
					success_border(element_id);
					document.getElementById('error_'+element_id).innerHTML = '';
				}
				else if(/^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/i.test(document.getElementById(element_id).value) && i!=total)
				{
					continue;
				}
				else
				{
					document.getElementById('error_'+element_id).innerHTML = 'Enter a valid email';
					fail_border(element_id);
					break;
				}
			}
			else
			{
				back_toclearBorder(element_id);
			}
		}
		if(ruleArray[i]=='username')
		{			
			if(document.getElementById(element_id).value.trim() != '')
			{
				if(document.getElementById(element_id).value.length>=6 && document.getElementById(element_id).value.length<26)
				{
					if(/^[a-zA-Z0-9\_\.]+$/i.test(document.getElementById(element_id).value) && i==total)
					{
						success_border(element_id);
					}
					else if(/^[a-zA-Z0-9\_\.]+$/i.test(document.getElementById(element_id).value) && i!=total)
					{
						continue;
					}
					else
					{
						document.getElementById('error_'+element_id).innerHTML = 'you can use only letters (a-z), numbers, and periods';
						fail_border(element_id);
						break;
					}
				}
				else
				{
					document.getElementById('error_'+element_id).innerHTML = 'Please use between 6 and 25 characters.';
					fail_border(element_id);
					break;
				}
			}
			else
			{
				back_toclearBorder(element_id);
			}
		}
		if(ruleArray[i]=='password')
		{
			if(document.getElementById(element_id).value.trim() != '')
			{
				if(document.getElementById(element_id).value.length>=6 && i==total)
				{
					success_border(element_id);
				}
				else if(document.getElementById(element_id).value.length>=6 && i!=total)
				{
					continue;
				}
				else
				{
					document.getElementById('error_'+element_id).innerHTML = 'password must be at least 6 characters long';
					fail_border(element_id);
					break;
				}
			}
			else
			{
				back_toclearBorder(element_id);
			}
		}
		if(ruleArray[i]=='telno')
		{
			if(document.getElementById(element_id).value.trim() != '')
			{
				if(/^[0-9]{10}$/i.test(document.getElementById(element_id).value) && i==total)
				{
					success_border(element_id);
				}
				else if(/^[0-9]{10}$/i.test(document.getElementById(element_id).value) && i!=total)
				{
					continue;
				}
				else
				{
					document.getElementById('error_'+element_id).innerHTML = 'only numbers';
					fail_border(element_id);
					break;
				}
			}
			else
			{
				back_toclearBorder(element_id);
			}
		}
		if(ruleArray[i]=='alpha')
		{
			if(document.getElementById(element_id).value.trim() != '')
			{
				if(/^[a-zA-Z]+$/i.test(document.getElementById(element_id).value) && i==total)
				{
					success_border(element_id);
				}
				else if(/^[a-zA-Z]+$/i.test(document.getElementById(element_id).value) && i!=total)
				{
					continue;
				}
				else
				{
					document.getElementById('error_'+element_id).innerHTML = 'only alphabets';
					fail_border(element_id);
					break;
				}
			}
			else
			{
				back_toclearBorder(element_id);
			}
		}
		if(ruleArray[i]=='dropdown')
		{
			if(document.getElementById(element_id).value!=0 && i==total)
			{
				success_border(element_id);
			}
			else if(document.getElementById(element_id).value!=0 && i!=total)
			{
				continue;
			}
			else
			{
				document.getElementById('error_'+element_id).innerHTML = 'select';
				fail_border(element_id);
				break;
			}
		}
		if(ruleArray[i]=='none')
		{
			back_toclearBorder(element_id);
		}
	}
}

/*Entire Form Validation*/

function formsubmit(NowBlock, formName, reqFieldArr ,nextAction){	
	var curForm = new formObj(NowBlock, formName, reqFieldArr ,nextAction);
    if(curForm.valid)
	{	
		return true;	
	}
	
    else{
		return false;
        curForm.paint();    
        curForm.listen();
    }	
}

function formObj(NowBlock, formName, reqFieldArr, nextAction){	

    var filledCount = 0;
    var fieldArr = new Array();
	var k = 0;
	this.formNM = formName;
	
	/*if(document.forms[this.formNM].elements['submit_tp'].value == '1ax')
	{
		this.nextaction = nextAction;
		this.now = NowBlock;
	}*/
	
	for(i=0;i<reqFieldArr.length;i++)
	{
		if(reqFieldArr[i][0]=='required')
		{				
			for(j=reqFieldArr[i].length-1; j>=1; j--){
				fieldArr[k] = new fieldObj(this.formNM, reqFieldArr[i][j],'required');
				if(fieldArr[k].filled == true)
				{
					filledCount++;
				}
				k++;
			}
		}
		if(reqFieldArr[i][0]=='email')
		{	
			for(j=reqFieldArr[i].length-1; j>=1; j--){
				fieldArr[k] = new fieldObj(this.formNM, reqFieldArr[i][j],'email');
				if(fieldArr[k].filled == true)
				{
					filledCount++;
				}
				k++;
			}
		}
		if(reqFieldArr[i][0]=='username')
		{	
			for(j=reqFieldArr[i].length-1; j>=1; j--){
				fieldArr[k] = new fieldObj(this.formNM, reqFieldArr[i][j],'username');
				if(fieldArr[k].filled == true)
				{
					filledCount++;
				}
				k++;
			}
		}
		if(reqFieldArr[i][0]=='password')
		{	
			for(j=reqFieldArr[i].length-1; j>=1; j--){
				fieldArr[k] = new fieldObj(this.formNM, reqFieldArr[i][j],'password');
				if(fieldArr[k].filled == true)
				{
					filledCount++;
				}
				k++;
			}
		}
		if(reqFieldArr[i][0]=='telno')
		{	
			for(j=reqFieldArr[i].length-1; j>=1; j--){
				fieldArr[k] = new fieldObj(this.formNM, reqFieldArr[i][j],'telno');
				if(fieldArr[k].filled == true)
				{
					filledCount++;
				}
				k++;
			}
		}
		if(reqFieldArr[i][0]=='alpha')
		{	
			for(j=reqFieldArr[i].length-1; j>=1; j--){
				fieldArr[k] = new fieldObj(this.formNM, reqFieldArr[i][j],'alpha');
				if(fieldArr[k].filled == true)
				{
					filledCount++;
				}
				k++;
			}
		}
		if(reqFieldArr[i][0]=='equal')
		{	
			for(j=reqFieldArr[i].length-1; j>=1; j--){
				fieldArr[k] = new fieldObj(this.formNM, reqFieldArr[i][j],'equal');
				if(fieldArr[k].filled == true)
				{
					filledCount++;
				}
				k++;
			}
		}
		if(reqFieldArr[i][0]=='notequal')
		{
			for(j=reqFieldArr[i].length-1; j>=1; j--){
				fieldArr[k] = new fieldObj(this.formNM, reqFieldArr[i][j],'notequal');
				if(fieldArr[k].filled == true)
				{
					filledCount++;
				}
				k++;
			}
		}
	}
    if(filledCount == fieldArr.length)
	{
        this.valid = true;
	}
    else
	{
        this.valid = false;
	}


    this.paint = function(){
        for(i=fieldArr.length-1; i>=0; i--){
            if(fieldArr[i].filled == false)
                fieldArr[i].paintInRed();
            else
                fieldArr[i].unPaintInRed();
        }
    }    
    this.listen = function(){
        for(i=fieldArr.length-1; i>=0; i--){
            fieldArr[i].fieldListen();
        }
    }	
}

formObj.prototype.send = function(){
		if(document.forms[this.formNM].elements['submit_tp'].value == '1ax')
		{
			var to = document.forms[this.formNM].elements['submit_action'].value;
			var tofunction = document.forms[this.formNM].elements['submit_fn'].value;			
			var now = this.now;
			var next = this.nextaction; 
			
			var str = $('#'+this.formNM).serialize();			
			
			var url = path+"index.php/"+to+"/"+tofunction;					
			$.post(url,{fieldval:str},function(data) {
				if(data=='next')
				{			
					if(next != 'none')
					{
						document.getElementById(now).style.display="none";
						document.getElementById(next).style.display="block";
						return true;
					}
				}
				else
				{					
					//document.getElementById('set_notset').value = 'notset';
				}															
			});
		}
		
		if(document.getElementById('submit_tp').value == '')
		{
			document.forms[this.formNM].submit();
			return true;
		}
};

function fieldObj(formName, fName,typeOchk){

	if(typeOchk != 'equal' && typeOchk != 'notequal')
	{
		var curField = document.forms[formName].elements[fName];
	}
    this.filled = getValueBool(typeOchk);

    this.paintInRed = function(){
		//document.getElementById('error_'+fName).innerHTML = 'required';
        //curField.addClassName('red');		
    }

    this.unPaintInRed = function(){
        //curField.removeClassName('red');
		//document.getElementById('error_'+fName).innerHTML = '';
    }

    this.fieldListen = function(){
        curField.onkeyup = function(){
            if(curField.value != ''){			
                curField.removeClassName('red');				
            }
            else{
                curField.addClassName('red');				
            }
        }
    }

    function getValueBool(type){
		if(type=='required')
		{
			if($.trim(curField.value) != '')
			{
				document.getElementById('error_'+fName).innerHTML = '';
				return true;
			}
			else
			{
				var chkvalue = document.getElementById('error_'+fName).innerHTML.trim();
				if(chkvalue == '')
				{
					document.getElementById('error_'+fName).innerHTML = 'Required';
					fail_border(fName);
				}
				return false;
			}
		}
		if(type=='email')
		{
			if($.trim(curField.value) != '')
			{			
				if(/^([a-z0-9\+_\-]+)(\.[a-z0-9\+_\-]+)*@([a-z0-9\-]+\.)+[a-z]{2,6}$/i.test(curField.value))
				{
					document.getElementById('error_'+fName).innerHTML = '';
					return true;
				}
				else
				{
					var chkvalue = document.getElementById('error_'+fName).innerHTML.trim();
					
					if(chkvalue == '')
					{				
						document.getElementById('error_'+fName).innerHTML = 'Enter a valid email';
						fail_border(fName);
					}
					return false;
				}
			}
			else
			{
				return true;
			}
		}
		if(type=='username')
		{
			if($.trim(curField.value) != '')
			{
				if(curField.value.length>=6 && curField.value.length<26)
				{
					if(/^[a-zA-Z0-9\_\.]+$/i.test(curField.value))
					{
						document.getElementById('error_'+fName).innerHTML = '';
						return true;
					}
					else
					{
						var chkvalue = document.getElementById('error_'+fName).innerHTML.trim();
					
						if(chkvalue == '')
						{				
							document.getElementById('error_'+fName).innerHTML = 'you can use only letters (a-z), numbers, and periods';
							fail_border(fName);
						}
						return false;
					}
				}
				else
				{
					var chkvalue = document.getElementById('error_'+fName).innerHTML.trim();
					
					if(chkvalue == '')
					{				
						document.getElementById('error_'+fName).innerHTML = 'Please use between 6 and 25 characters.';
						fail_border(fName);
					}
					return false;
				}
			}
			else
			{
				return true;
			}
		}
		if(type=='password')
		{
			if($.trim(curField.value) != '')
			{
				if(curField.value.length>=6)
				{
					document.getElementById('error_'+fName).innerHTML = '';
					return true;
				}
				else
				{
					var chkvalue = document.getElementById('error_'+fName).innerHTML.trim();
					
					if(chkvalue == '')
					{				
						document.getElementById('error_'+fName).innerHTML = 'password must be at least 6 characters long';
						fail_border(fName);
					}
					return false;
				}
			}
			else
			{
				return true;
			}
		}
		if(type=='telno')
		{
			if($.trim(curField.value) != '')
			{
				if(/^[0-9]{10}$/i.test(curField.value))
				{
					document.getElementById('error_'+fName).innerHTML = '';
					return true;
				}
				else
				{
					var chkvalue = document.getElementById('error_'+fName).innerHTML.trim();
					
					if(chkvalue == '')
					{				
						document.getElementById('error_'+fName).innerHTML = 'Enter a valid phone number';
						fail_border(fName);
					}
					return false;
				}
			}
			else
			{
				return true;
			}
		}
		if(type=='alpha')
		{
			if($.trim(curField.value) != '')
			{
				if(/^[a-zA-Z]+$/i.test(curField.value))
				{
					document.getElementById('error_'+fName).innerHTML = '';
					return true;
				}
				else
				{
					var chkvalue = document.getElementById('error_'+fName).innerHTML.trim();
					
					if(chkvalue == '')
					{				
						document.getElementById('error_'+fName).innerHTML = 'sholud be a charector';
						fail_border(fName);
					}
					return false;
				}
			}
			else
			{
				return true;
			}
		}
		if(type=='equal')
		{
		
			FfName = fName[0];
			LfName = fName[1];
			var FcurField = document.forms[formName].elements[FfName];
			var LcurField = document.forms[formName].elements[LfName];	
			if($.trim(FcurField.value) != '')
			{
				if($.trim(FcurField.value)==$.trim(LcurField.value))
				{
					document.getElementById('error_'+LfName).innerHTML = '';
					return true;
				}
				else
				{
					var chkvalue = document.getElementById('error_'+LfName).innerHTML.trim();
					if(chkvalue == '')
					{				
						document.getElementById('error_'+LfName).innerHTML = 'sholud be same';
						fail_border(LfName);
					}					
					return false;
				}
			}
			else
			{
				return true;
			}
		}
		if(type=='notequal')
		{			
			var FfName = fName[0];	
			var Fvalue = document.forms[formName].elements[FfName].value;
			var Tvalue = fName[1];
			
			if(Fvalue!=Tvalue)
			{			
				elem = document.forms[formName].elements[FfName].setAttribute("style","border: 1px solid #ccc; box-shadow: none;");
				return true;
			}
			else
			{				
				elem = document.forms[formName].elements[FfName].setAttribute("style","border: 1px solid #EF672F; box-shadow: 0 0 2px #EF672F;");	
				return false;
			}			
		}
    }
}
	
/*END*/


function success_border(id)
{
	$('#'+id).removeClass('input__error');
	// elem = document.getElementById(id);
	// elem.setAttribute("style","border: 1px solid #D3D3D3; box-shadow: none;");
	// document.getElementById('error_'+id).innerHTML = '';
	// document.getElementById('error_'+id).style.display = 'none';
}

function fail_border(id)
{
	$('#'+id).addClass('input__error');
	// elem = document.getElementById(id);
	// elem.setAttribute("style","border: 1px solid #EF672F; box-shadow: 0 0 2px #EF672F;");	
	// document.getElementById('error_'+id).style.display = 'block';	
}

function focus_border(id)
{
	elem = document.getElementById(id);
	elem.setAttribute("style","outline:none; border-color: #4D90FE; box-shadow: 0 0 2px #4D90FE;");
}
function back_toclearBorder(id)
{
	elem = document.getElementById(id);
	elem.setAttribute("style","border: 1px solid #D3D3D3; box-shadow: none;");
}

/*---------- newly added 22/07/2015 ------------*/
function search_cover()
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/cover/search_cover";	
	$.post(url,{},function(data) {	
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});
}


/*-----------------------Manage County-----------------------*/

function partnersaddpopup()
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/manage_partner/add";	
	$.post(url,{},function(data) {	
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});
}

function partnerseditpopup(id)
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/manage_partner/edit";	
	$.post(url,{id:id},function(data) {	
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});
}

/* Bulk Upload */

function bulk_upload()
{
	var pathstring = String(window.location);
	var patharray  = pathstring.split("/");		
	var path=patharray[0]+'//'+patharray[2]+'/'+patharray[3];
	var url = path+"/index.php/dashboard/bulk_upload";	
	$.post(url,{},function(data) {	
		if(data!='')
		{
			$("html, body").animate({ scrollTop: 0 }, 500);					
			$('.popup__content').html(data);
			$('.popup-background').addClass('popup-widget-overlay');
			$('.popup-popup-content').css({
				'display': 'block',
				'height': 'auto',
				'left': '33%',
				'position': 'absolute',
				'top': '17px',
				'width': '535px',
				'z-index': '999'
			});
		}
		else
		{
			var form='Invalid Request';
		}
	});
}